## Título: Regressão Dividendos ----------------------------------------------------------------------------------------------------------------
## Autor: Análise & Gestão - 4UM Investimentos
## Data: 04/04/2022

## Pacotes Utilizados --------------------------------------------------------------------------------------------------------------------------

library(mise)
library(tidyverse)
library(stringr)
library(readxl)
library(zoo)
library(stargazer)
library(magrittr)

## Diretório de Trabalho -----------------------------------------------------------------------------------------------------------------------

mise(vars = TRUE, figs = TRUE, console = FALSE)
setwd(dir = 'D:/OneDrive/Área de Trabalho/Regressão Dividendos')

## Setup de Informações ------------------------------------------------------------------------------------------------------------------------

filtro_liquidez <- 1000 # Indicar, em valores, o filtro mínimo de negócios no trimestre.
filtro_pl <- 0 # Indicar, em valores, o mínimo valor de mercado da empresa no trimestre.

janela_1 <- seq(from = as.Date(x = '2001-03-01'), to = as.Date(x = '2006-12-01'), by = 'quarters') # Janela de tempo arbitrária 1.
janela_2 <- seq(from = as.Date(x = '2010-03-01'), to = as.Date(x = '2014-12-01'), by = 'quarters') # Janela de tempo arbitrária 2.
janela_3 <- seq(from = as.Date(x = '2015-03-01'), to = as.Date(x = '2016-12-01'), by = 'quarters') # Janela de tempo arbitrária 3.
janela_4 <- seq(from = as.Date(x = '2017-03-01'), to = as.Date(x = '2019-12-01'), by = 'quarters') # Janela de tempo arbitrária 4.
janela_5 <- seq(from = as.Date(x = '2020-03-01'), to = as.Date(x = '2021-12-01'), by = 'quarters') # Janela de tempo arbitrária 5.

## Manipulação da Base de Dados ----------------------------------------------------------------------------------------------------------------

base_dados <- tibble(read.csv(file = 'Dados.csv', header = TRUE, sep = ',', dec = '.', na.strings = '-')) %>%
  rename(ativo = Ativo,
         data = Data,
         volatilidade = Volatilidade.base.anual.1.anos.Em.moeda.orig,
         beta = Beta.1.anos.Em.moeda.orig,
         pvpa = P.VPA.Em.moeda.orig.consolid.sim.,
         pl = P.L.Em.moeda.orig.de.12.meses.consolid.sim.,
         div_yield = Div.Yld..fim..1.anos.Em.moeda.orig,
         vm = Valor.Mercado.da.empresa.Em.moeda.orig.em.milhares,
         retorno = Retorno.do.fechamento.em.4.trimestres.Em.moeda.orig.ajust.p..prov,
         nulos = Media.nulos...0.do.volume..em.1.ano.Em.moeda.orig.em.milhares,
         presenca = Presença.1.anos,
         negocios = Q.Negs) %>%
  mutate(ativo = str_remove(string = ativo, pattern = '<XBSP>'),
         data = (as.Date(x = as.yearqtr(x = str_replace_all(string = data, 
                                                            pattern = c('1T', '2T', '3T', '4T'), 
                                                            replacement = c('01', '02', '03', '04')), 
                                        format = '%q%Y'))) + months(2),
         dummie_liq = ifelse(test = negocios >= filtro_liquidez, yes = 1, no = 0),
         dummie_pl = ifelse(test = vm >= filtro_pl, yes = 1, no = 0)) %>%
  full_join(x = tibble(read_xlsx(path = 'CDI e IBOV.xlsx')) %>% 
                mutate(data = as.Date(x = data)))

## Modelo de Regressão Linear ------------------------------------------------------------------------------------------------------------------

modelo_1 <- lm(formula = retorno ~ div_yield + cdi, data = base_dados %>% filter(data %in% janela_1,
                                                                          dummie_liq == 1,
                                                                          dummie_pl == 1))

modelo_2 <- lm(formula = retorno ~ div_yield + cdi, data = base_dados %>% filter(data %in% janela_2,
                                                                          dummie_liq == 1,
                                                                          dummie_pl == 1))

modelo_3 <- lm(formula = retorno ~ div_yield + cdi, data = base_dados %>% filter(data %in% janela_3,
                                                                          dummie_liq == 1,
                                                                          dummie_pl == 1))

modelo_4 <- lm(formula = retorno ~ div_yield + cdi, data = base_dados %>% filter(data %in% janela_4,
                                                                          dummie_liq == 1,
                                                                          dummie_pl == 1))

modelo_5 <- lm(formula = retorno ~ div_yield + cdi, data = base_dados %>% filter(data %in% janela_5,
                                                                          dummie_liq == 1,
                                                                          dummie_pl == 1))
  
## Visualização dos Resultados -----------------------------------------------------------------------------------------------------------------

stargazer(modelo_1, modelo_2, modelo_3, modelo_4, modelo_5, type = 'text')

## Testes Estatísticos -------------------------------------------------------------------------------------------------------------------------

# Normalidade.
# Multicolinearidade.
# Heterocedasticidade.
# Autocorrelação serial.

